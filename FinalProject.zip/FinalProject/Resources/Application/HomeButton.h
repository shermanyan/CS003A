//
// Created by Sherman Yan on 12/8/22.
//

#ifndef FINALPROJECT_HOMEBUTTON_H
#define FINALPROJECT_HOMEBUTTON_H
#include "SFML/Graphics.hpp"
#include "Textures.h"
#include "SpriteImage.h"


class HomeButton : public SpriteImage{
public:
    HomeButton();
};


#endif //FINALPROJECT_HOMEBUTTON_H
