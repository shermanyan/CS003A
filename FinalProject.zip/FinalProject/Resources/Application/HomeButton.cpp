//
// Created by Sherman Yan on 12/8/22.
//

#include "HomeButton.h"

HomeButton::HomeButton() {
    setTexture(Textures::getTexture(HOME));
    setSize({50, 50});
}

