//
// Created by Sherman Yan on 12/9/22.
//

#ifndef FINALPROJECT_SCROLLENUM_H
#define FINALPROJECT_SCROLLENUM_H

enum ScrollEnum{
    VERTICAL, HORIZONTAL
};
#endif //FINALPROJECT_SCROLLENUM_H
