//
// Created by Sherman Yan on 12/6/22.
//

enum FontsEnum{
    COURIER,
    OPEN_SANS,
    PTSERIF_BOLD,
    SONO_BOLD,
    TITAN_ONE,
    LILITA_ONE,
    RUBIK_GEMSTONES,
    LAST_FONT
};