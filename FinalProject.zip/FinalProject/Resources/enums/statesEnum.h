//
// Created by Sherman Yan on 12/8/22.
//

#ifndef FINALPROJECT_STATESENUM_H
#define FINALPROJECT_STATESENUM_H

enum StatesEnum{
    HIDDEN,
    PLAY,
    LAST_STATE
};

#endif //FINALPROJECT_STATESENUM_H
