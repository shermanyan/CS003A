//
// Created by Sherman Yan on 12/6/22.
//

enum TextureEnums{
    HOME,
    SKIRT,
    CLUB,
    DIAMOND,
    HEART,
    SPADE,
    VESSEL,
    TRASH_1,
    TRASH_2,
    TRASH_3,
    TRASH_4,
    TRASH_5,
    TRASH_6,
    LAST_TRASH,
    GP_GREEN_BALL,
    GP_BOUNCING_BALL,
    GP_OCEAN_CLEANUP,
    GP_PLAYING_CARD,
    GP_POKER_ANALYSIS,
    GP_PONG,
    GP_TOP_HAT_GUY,
    LAST_IMG
};