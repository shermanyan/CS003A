//
// Created by Sherman Yan on 12/8/22.
//

#include "App_GreenBall.h"

App_GreenBall::App_GreenBall(): DisplayableApplication("Green Ball") {
    addComponent(g);
}
