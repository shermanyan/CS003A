//
// Created by Sherman Yan on 12/8/22.
//

#ifndef FINALPROJECT_APP_GREENBALL_H
#define FINALPROJECT_APP_GREENBALL_H
#include "DisplayableApplication.h"
#include "GreenBall.h"

class App_GreenBall: public DisplayableApplication {
private:
    GreenBall g;
public:
    App_GreenBall();
};


#endif //FINALPROJECT_APP_GREENBALL_H
