//
// Created by Sherman Yan on 12/9/22.
//

#include "App_TopHatGuy.h"

App_TopHatGuy::App_TopHatGuy():
DisplayableApplication{"Top Hat Guy"} {
    addComponent(t);
}
