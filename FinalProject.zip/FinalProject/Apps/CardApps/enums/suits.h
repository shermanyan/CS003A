//
// Created by Sherman Yan on 11/7/22.
//

#ifndef CS003A_SUITS_H
#define CS003A_SUITS_H

enum suits {
    HEARTS, DIAMONDS, CLUBS, SPADES
};

#endif //CS003A_SUITS_H
