//
// Created by Sherman Yan on 11/7/22.
//

#ifndef CS003A_RANKS_H
#define CS003A_RANKS_H

enum ranks{
    ACE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE, TEN, JACK, QUEEN, KING
};
#endif //CS003A_RANKS_H
