//
// Created by Sherman Yan on 12/8/22.
//

#include "App_PlayingCard.h"

App_PlayingCard::App_PlayingCard(): DisplayableApplication{"Playing Card"} {
    addComponent(p);
}
