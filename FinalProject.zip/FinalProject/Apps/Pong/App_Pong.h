//
// Created by Sherman Yan on 12/7/22.
//

#ifndef FINALPROJECT_APP_PONG_H
#define FINALPROJECT_APP_PONG_H


#include "DisplayableApplication.h"
#include "Pong.h"

class App_Pong: public DisplayableApplication{
private:
    Pong p;
public:
    App_Pong();
};


#endif //FINALPROJECT_APP_PONG_H
