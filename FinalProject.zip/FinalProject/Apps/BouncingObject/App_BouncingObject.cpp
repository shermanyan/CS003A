//
// Created by Sherman Yan on 12/7/22.
//

#include "App_BouncingObject.h"

App_BouncingObject::App_BouncingObject():
DisplayableApplication{"Bouncing Ball",{063,136,143}} {
    addComponent(b);
}

