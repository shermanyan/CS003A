//
// Created by Sherman Yan on 12/7/22.
//

#ifndef FINALPROJECT_BALL_H
#define FINALPROJECT_BALL_H

#include <SFML/Graphics.hpp>

class Ball : public sf::CircleShape{
public:
    void setSize(sf::Vector2f size);
};


#endif //FINALPROJECT_BALL_H
