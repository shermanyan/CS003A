//
// Created by Sherman Yan on 12/14/22.
//

#include "App_OceanCleanup.h"

App_OceanCleanup::App_OceanCleanup():
DisplayableApplication{"Ocean Cleanup", {51,145,199}} {
    addComponent(o);
}
