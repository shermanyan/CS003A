//
// Created by Sherman Yan on 12/14/22.
//

#ifndef FINALPROJECT_APP_OCEANCLEANUP_H
#define FINALPROJECT_APP_OCEANCLEANUP_H
#include "DisplayableApplication.h"
#include "OceanCleanup.h"

class App_OceanCleanup : public DisplayableApplication{
private:
    OceanCleanup o;
public:
    App_OceanCleanup();
};


#endif //FINALPROJECT_APP_OCEANCLEANUP_H
