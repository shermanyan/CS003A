//
// Created by Sherman Yan on 12/10/22.
//

#ifndef FINALPROJECT_APP_GAMESELECTOR_H
#define FINALPROJECT_APP_GAMESELECTOR_H

#include "DisplayableApplication.h"
#include "GameSelector.h"
class App_GameSelector: public DisplayableApplication{
private:
    GameSelector g;
public:
    App_GameSelector();
};


#endif //FINALPROJECT_APP_GAMESELECTOR_H
